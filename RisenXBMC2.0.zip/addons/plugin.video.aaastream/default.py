# -*- coding: utf-8 -*-
# h@k@M@c Code x3

aaastreamversion = "V1.9.2Build26"
aaastreamdate = "12/03/2015 17:00hrs GMT"

import urllib, sys, xbmcplugin ,xbmcgui, xbmcaddon, xbmc, os, json, time, base64
import re,urllib2
import xbmcplugin,random,urlparse,urlresolver
from t0mm0.common.addon import Addon
from metahandler import metahandlers
from addon.common.net import Net

PlaylistUrl = "http://aaastream.com"
AddonID = 'plugin.video.aaastream'
Addon = xbmcaddon.Addon(AddonID)
localizedString = Addon.getLocalizedString
localisedTranslate = 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcucGhwP2k9MUZrWjlhTUQ='
localisedMoLink = 'aHR0cDovL2tvZGkueHl6L21vdmllcy5waHA='
localisedCatLink = 'aHR0cDovL21vdmllc2hkLmNvL2dlbnJl'
LocalisedLa = 'aHR0cDovL3d3dy5tb3ZpZTI1LmFnLw=='
Raw = base64.decodestring('aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcucGhwP2k9')
LibDBLink = base64.decodestring('aHR0cDovL2ltdmRiLmNvbS8=')
DirectoryMSG = "[COLOR yellow][B]--[/COLOR][COLOR green] Find us on Facebook 'AAA Stream Users'[/COLOR] [COLOR yellow]--[/COLOR][/B]"
net = Net()
AddonName = Addon.getAddonInfo("name")
fanart = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.aaastream/fanart.jpg'))
artpath = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.aaastream/resources/art/'))
icon = Addon.getAddonInfo('icon')
addonDir = Addon.getAddonInfo('path').decode("utf-8")
LibCommon = len(PlaylistUrl)
libDir = os.path.join(addonDir, 'resources', 'lib')
sys.path.insert(0, libDir)
custurltv = str(base64.decodestring('aHR0cDovL3d3dy50dm9ubGluZS50dy8='))
import common

metaget = metahandlers.MetaData(preparezip=False)
metaset = 'true'
custurl1 = str(base64.decodestring(LocalisedLa))

 
addon_data_dir = os.path.join(xbmc.translatePath("special://userdata/addon_data" ).decode("utf-8"), AddonID)
if not os.path.exists(addon_data_dir):
	os.makedirs(addon_data_dir)
	
tmpListFile = os.path.join(addonDir, 'tempList.txt')
favoritesFile = os.path.join(addonDir, 'favorites.txt')
if  not (os.path.isfile(favoritesFile)):
	f = open(favoritesFile, 'w') 
	f.write('[]') 
	f.close() 

# husham cant code for sh*t lol! 
def Categories():
    Version = '[COLOR yellow][B]*FAILED TO CONNECT*[/B][/COLOR]'
    try: Version = net.http_GET(Raw+'1FkZ9aMD').content
    except: AddDir("[COLOR red][B] BAD CONNECTION [/B][/COLOR]", "Update" ,98, "http://s5.postimg.org/6lxz2d087/appgraphic.png")

    if Version != aaastreamdate and Version != '[COLOR yellow][B]*FAILED TO CONNECT*[/B][/COLOR]':
           UpdateMe()
           xbmc.executebuiltin("UpdateLocalAddons")

   
    AddDir("[COLOR white][B] "+aaastreamversion+" [/B][/COLOR]", "Update" ,98, "http://s5.postimg.org/6lxz2d087/appgraphic.png")
   
    AddDir("[COLOR white][B] UPDATE[/B][/COLOR]", "Update" ,50, "http://s5.postimg.org/pgtpss09z/update.png")
    AddDir("[COLOR white][B] FAVOURITES[/B][/COLOR]", "favorites" ,30 ,"http://s5.postimg.org/60906955z/favorite.png") 
    AddDir("[COLOR white][B] TV BOXES[/B][/COLOR]", "pZaJ0peV" ,35 ,"http://s5.postimg.org/867wehy07/suppliers.png")
        
    AddDir("[COLOR white][B] LIVE STREAMS[/B][/COLOR]", "JJHkScbY" ,59 ,"http://s5.postimg.org/eazertq3r/live_streams.png")
    AddDir("[COLOR white][B] LIVE SPORT[/B][/COLOR]", "H7mZc5LE" ,59 ,"http://s5.postimg.org/jawuzrvqf/sport.png")
    AddDir("[COLOR white][B] COUNTRY [/B][/COLOR]",'Bqdg4C4g',59 ,"http://s5.postimg.org/lpoqk7bzb/country.png")  
    AddDir("[COLOR white][B] MOVIES[/B][/COLOR]",'movies',44 ,"http://s5.postimg.org/ltik0ghgn/movies.png")
    AddDir("[COLOR white][B] TV SHOWS[/B][/COLOR]",'TV',45 ,"http://s5.postimg.org/fh3eqmeef/image.png") 	
    AddDir("[COLOR white][B] MUSIC[/B][/COLOR]", "Music" ,101 ,"http://s5.postimg.org/asoby6n3b/music.png")
    AddDir("[COLOR white][B] NEWSLETTER[/B][/COLOR]", Raw+"6DAkzFZc" ,2 ,"http://s5.postimg.org/mmv5t2nhj/newsletter.png")
    AddDir("[COLOR white][B] SUPPORT[/B][/COLOR]", Raw+"jXTjzCfL" ,2 ,"http://s5.postimg.org/cbit0evs7/support.png")
    AddDir("[COLOR white][B] facebook.com/aaastream    website: aaastream.com[/B][/COLOR]", "Update" ,98, "http://s5.postimg.org/7hz1vjzaf/facebook.png")
    
    AddDir("[COLOR white][B] COMMING SOON[/B][/COLOR]", "EMPTY" ,98 ,"http://s5.postimg.org/sp2sjkbxj/underconstruction.png")
    xbmc.executebuiltin("Container.SetViewMode(500)") 
    


#aaastream New security key U1R1A6P4R9I3C1K
def MOVIES():
        AddDir("[COLOR white][B]FAVOURITES[/B][/COLOR]", "favorites" ,30 ,"http://s5.postimg.org/60906955z/favorite.png") 
        AddDir("[COLOR white][B]Selected[/B][/COLOR]",str(base64.decodestring(localisedMoLink)),43 ,"http://s5.postimg.org/ltik0ghgn/movies.png")
        AddDir("[COLOR white][B]Categories[/B][/COLOR]",base64.decodestring('aHR0cDovL21vdmllc2hkLmNvL2dlbnJl') ,47 ,"http://s5.postimg.org/6syn25s9z/category.png")
        AddDir('[COLOR white][B]Top 9[/B][/COLOR]',custurl1,51,"http://s5.postimg.org/4rq6hqjjb/top9.png")
        AddDir('[COLOR white][B]Featured[/B][/COLOR]',custurl1+'featured-movies/',52,"http://s5.postimg.org/am5kxz7mv/featured.png")
        AddDir('[COLOR white][B]New Releases[/B][/COLOR]',custurl1+'new-releases/',52,"http://s5.postimg.org/xsuir53zb/new.png")
        AddDir('[COLOR white][B]Latest Added[/B][/COLOR]',custurl1+'latest-added/',52,"http://s5.postimg.org/5rghdfyp3/latest_added.png")
        AddDir('[COLOR white][B]HD[/B][/COLOR]',custurl1+'latest-hd-movies/',52,"http://s5.postimg.org/pwa1iwsiv/image.png")
        AddDir('[COLOR white][B]Most Viewed[/B][/COLOR]',custurl1+'most-viewed/',52,"http://s5.postimg.org/br48h3jhj/mostviewed.png")
        AddDir('[COLOR white][B]Search[/B][/COLOR]',custurl1+'most-viewed/',79,"http://s5.postimg.org/rhpbaq2qv/search.png")
        xbmc.executebuiltin("Container.SetViewMode(500)") 
        
def TV():
        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
        AddDir("[COLOR white][B] YOUR FAVOURITE CHANNELS HERE[/B][/COLOR]", "favorites" ,30 ,"http://s5.postimg.org/60906955z/favorite.png") 
        AddDir('[COLOR white]Newest Episodes [/COLOR]',custurltv+'new-episodes/',77,'http://s5.postimg.org/xsuir53zb/new.png')
        AddDir('[COLOR white]Latest Added[/COLOR]',custurltv+'latest-added/',75,'http://s5.postimg.org/5rghdfyp3/latest_added.png')
      
        AddDir('[COLOR white]Search [/COLOR]',custurltv,78,'http://s5.postimg.org/rhpbaq2qv/search.png')
        AddDir('[COLOR white]A-Z[/COLOR]',custurltv+'tv-listings/0-9',82,'http://s5.postimg.org/t19z1a4x3/tvshows.jpg')
        xbmc.executebuiltin("Container.SetViewMode(500)")
		
        GenresPage = net.http_GET(custurltv+'genres/action').content
        GenresPage = GenresPage.encode('ascii', 'ignore').decode('ascii')
        NotNeeded, GenresPage = GenresPage.split('<div class="tv_letter_nav"><ul>')
        GenresPage , NotNeeded = GenresPage.split('<div class="tv_all">')
        GenresPage = GenresPage.replace('\"','').replace(')','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')

        match=re.compile("<a href=/(.+?)>(.+?)</a>",re.DOTALL).findall(str(GenresPage))
		
        for url,name in match:
                name = CLEAN(name)
                AddDir('[COLOR white]'+name+'[/COLOR]',custurltv+url,83,"http://www.iconarchive.com/download/i14263/hydrattz/multipurpose-alphabet/Letter-"+name[:1]+"-black.ico")

def MusicVideos(url):
    MusicAddDir('New Picks', LibDBLink + 'picks',102,"http://s5.postimg.org/xsuir53zb/new.png",'n')
    MusicAddDir('Latest Videos', LibDBLink + 'new',102,"http://s5.postimg.org/5rghdfyp3/latest_added.png",'n')
    MusicAddDir('Genres', LibDBLink + 'genres',103,"http://s5.postimg.org/9rkgllr3b/music_genre.png",'n')
    MusicAddDir('Charts New', LibDBLink + 'charts/new',104,"http://s5.postimg.org/tap1uypuv/music_charts_new.png",'n')
    MusicAddDir('AtoZ Artist', LibDBLink + 'browse/artists/',105,"http://s5.postimg.org/75nbnmtev/atoz.png",'n')
    MusicAddDir('Search Artist', LibDBLink ,105,"http://s5.postimg.org/sp2sjkbxj/underconstruction.png",'n')
    MusicAddDir('Search Song', LibDBLink ,106,"http://s5.postimg.org/sp2sjkbxj/underconstruction.png",'n')
    
    MusicAddDir('Construction', LibDBLink ,0,"http://s5.postimg.org/sp2sjkbxj/underconstruction.png",'n')
    MusicAddDir('Construction', LibDBLink ,0,"http://s5.postimg.org/sp2sjkbxj/underconstruction.png",'n')
    
    xbmc.executebuiltin("Container.SetViewMode(500)")
		
def Music_video_list(name,url):
    
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
    if 'http://imvdb.com/genre' in url:
        all_videos = regex_get_all(link, '<div class="slideNode', 'p class="node_info')
        for a in all_videos:
            if not 'Not Available Online' in a:
                vurl = regex_from_to(a, '<a href="', '"')
                iconimage = regex_from_to(a, '<img class="rack_img" src="', '"').replace('tv.jpg', 'bv.jpg')
                songinfo = regex_from_to(a, '<h3>', '</h3>')
                song = regex_from_to(songinfo, '">', '<').rstrip()
                artistinfo = regex_from_to(a, '<h4>', '</h4>')
                artist = regex_from_to(artistinfo, '">', '<')
                artisturl = regex_from_to(artistinfo, 'href="', '"')
                title = "[COLOR gold]%s[/COLOR] | [COLOR cyan]%s[/COLOR]" % (artist,song)
                MusicAddDirVideo(title,vurl,120,iconimage,song,artist,artisturl,'','')
    else:
        all_videos = regex_get_all(link, '<div class="rack_node', '</div>')
        for a in all_videos:
            if not 'Not Available Online' in a:
                vurl = regex_from_to(a, '<a href="', '"')
                iconimage = regex_from_to(a, '<img class="rack_img" src="', '"').replace('tv.jpg', 'bv.jpg')
                song = regex_from_to(a, 'title="', '">').rstrip()
                artistinfo = regex_from_to(a, '<h4>', '</h4>')
                artist = regex_from_to(artistinfo, '">', '<')
                artisturl = regex_from_to(artistinfo, 'href="', '"')
                title = "[COLOR gold]%s[/COLOR] | [COLOR cyan]%s[/COLOR]" % (artist,song)
                MusicAddDirVideo(title,vurl,120,iconimage,song,artist,artisturl,'','')
       
    xbmc.executebuiltin("Container.SetViewMode(500)")

def video_artists(name,url):
    alphabet =  ['0-9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U','V', 'W', 'X', 'Y', 'Z']
    for a in alphabet:
        MusicAddDir(a,url+a.lower(),106,"http://www.iconarchive.com/download/i14263/hydrattz/multipurpose-alphabet/Letter-"+a.upper()+"-black.ico",'1')
    
    xbmc.executebuiltin("Container.SetViewMode(500)")
	
def Get_video_artists_AZ(name,url):
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
	
    AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
	
    all_artists = regex_from_to(link, 'ul class="nameList">', '<div id="footer">')
    match = re.compile('<li><a href="(.+?)">(.+?)</a></li>').findall(all_artists)
    for url, title in match:
        MusicAddDir(title,url,107,'','n')
		
    xbmc.executebuiltin("Container.SetViewMode(50)")	

def Music_artist_videos(name,url):
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
    try:
        artistlst = regex_from_to(link, '<div id="artist-credits"', '</tbody>')
    except:
        try:
            artistlst = regex_from_to(link, '<div id="director-credits"', '</tbody>')
        except:
            artistlst = regex_from_to(link, '<div id="animator-credits"', '</tbody>')
    all_videos = regex_get_all(artistlst, '<tr', '<span><em>Director')
    for a in all_videos:
        vurl = regex_from_to(a, '<a href="', '"')
        iconimage = regex_from_to(a, 'data-src="', '"').replace('tv.jpg', 'bv.jpg')
        songinfo = regex_from_to(a, '<td width="40%"><strong>', 'a>')
        song = regex_from_to(songinfo, '">', '<').rstrip()
        artist = name
        artisturl = url
        title = "[COLOR gold]%s[/COLOR] | [COLOR cyan]%s[/COLOR]" % (artist,song)
        MusicAddDirVideo(title,vurl,120,iconimage,song,artist,artisturl,'','videoartist')	

    xbmc.executebuiltin("Container.SetViewMode(500)")
		
def Music_video_genres(name,url):
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
    all_genres = regex_get_all(link, '<div class="glassBox">', '</div>')
    loadedLinks = 0
    dialogWait = xbmcgui.DialogProgress()
	
    ret = dialogWait.create('Please wait until list is cached.')
    remaining_display = 'loaded :: [B]'+str(loadedLinks)+'[/B]'
    dialogWait.update(0, '[B]Will load instantly from now on[/B]',remaining_display)
    xbmc.executebuiltin("XBMC.Dialog.Close(busydialog,true)")
	
    AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
    for a in all_genres:
        url = regex_from_to(a, 'href="', '"')
        title = regex_from_to(a, '</i>', '<').lstrip()
        iconimage = regex_from_to(a, 'image: url', '"').replace('(','').replace(')','')
        
        loadedLinks = loadedLinks + 1
        remaining_display = 'loaded :: [B]'+str(loadedLinks)+' : '+str(title)+'[/B].'
        dialogWait.update(0, '[B]Will load instantly from now on[/B]',remaining_display)
        MusicAddDir(title,url,102,iconimage,'1')
        if dialogWait.iscanceled(): return False 
		
    dialogWait.close()
    del dialogWait
 
    xbmc.executebuiltin("Container.SetViewMode(500)")
	
def Music_Charts_New(name,url):
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
    AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
    all_genres = regex_get_all(link, '<td style="width: 50px">', '</td>')
    Position = 0
    for a in all_genres:
        url = regex_from_to(a, 'href="', '"')
        iconimage = regex_from_to(a, 'img src="', '"')
        title = regex_from_to(a, 'alt="', '"').lstrip()
        Position = Position + 1
        title = str(Position) + ' ' + title
#        xbmcgui.Dialog().ok(str(title), url)
        MusicAddDirVideo(title,url,120,iconimage,'','','','','')
		
	xbmc.executebuiltin("Container.SetViewMode(500)")
		
def MusicAddDir(name,url,mode,iconimage,artist):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&artist="+urllib.quote_plus(artist)
        ok=True
        type1=artist
        artist = artist.replace('qq','')
        suffix = ""
        if artist == "artists":
            list = "%s<>%s" % (str(name),url)
        else:
            if 'qq' in type1:
                spltype1 = type1.split('qq')
                list = "%s<>%s<>%s<>%s" % (str(name).lower(),url,str(iconimage),spltype1[0])
            else:
                list = "%s<>%s<>%s" % (str(name).lower(),url,str(iconimage))
        list = list.replace(',', '')
        
        contextMenuItems = []
        if artist == "videoartist":
            if find_list(list, FAV_VIDEOARTIST) < 0:
                suffix = ""
                contextMenuItems.append(("[COLOR lime]Add to Favourite Artists[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=1327&iconimage=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage))))
            else:
                suffix = ' [COLOR lime]+[/COLOR]'
                contextMenuItems.append(("[COLOR orange]Remove from Favourite Artists[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=1328&iconimage=%s)'%(sys.argv[0], name, urllib.quote(url), urllib.quote(iconimage))))
        if artist == "artists":
            if find_list(list, FAV_ARTIST) < 0:
                suffix = ""
                contextMenuItems.append(("[COLOR lime]Add to Favourite Artists[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=61&iconimage=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage))))
            else:
                suffix = ' [COLOR lime]+[/COLOR]'
                contextMenuItems.append(("[COLOR orange]Remove from Favourite Artists[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=62&iconimage=%s)'%(sys.argv[0], name, urllib.quote(url), urllib.quote(iconimage))))
        if len(artist)>2 and artist != "videoartist" and 'itemvn' not in url:
            download_album = '%s?name=%s&url=%s&iconimage=%s&artist=%s&mode=202' % (sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage),urllib.quote(artist))  
            contextMenuItems.append(('[COLOR cyan]Download Album[/COLOR]', 'XBMC.RunPlugin(%s)' % download_album))
            if QUEUE_ALBUMS:
                play_music = '%s?name=%s&url=%s&iconimage=%s&mode=7' % (sys.argv[0], urllib.quote(name), url, iconimage)  
                contextMenuItems.append(('[COLOR cyan]Play/Browse Album[/COLOR]', 'XBMC.RunPlugin(%s)' % play_music))
            else:
                queue_music = '%s?name=%s&url=%s&iconimage=%s&mode=6&artist=%s' % (sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage), urllib.quote(artist))  
                contextMenuItems.append(('[COLOR cyan]Queue[/COLOR]', 'XBMC.RunPlugin(%s)' % queue_music))
            if not 'qq' in type1:
                suffix = ""
                contextMenuItems.append(("[COLOR lime]Add to Favourite Albums[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=64&iconimage=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage))))
            else:
                suffix = ' [COLOR lime]+[/COLOR]'
                contextMenuItems.append(("[COLOR orange]Remove from Favourite Albums[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=65&iconimage=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(artist), urllib.quote(iconimage))))
        liz=xbmcgui.ListItem(name + suffix, iconImage="DefaultAudio.png", thumbnailImage=iconimage)
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        liz.setInfo( type="Audio", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', iconimage)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def MusicAddDirVideo(name,url,mode,iconimage,songname,artist,album,dur,type):
        suffix = ""
        if 'qq' in dur:
            list = "%s<>%s<>%s<>%s<>%s<>%s" % (str(artist),str(album),str(songname).lower(),url,str(iconimage),str(dur).replace('qq',''))
        else:
            list = "%s<>%s<>%s<>%s<>%s" % (str(artist),str(album),str(songname).lower(),url,str(iconimage))
        list = list.replace(',', '')
        artistsong = "%s - %s" % (artist,songname)
        contextMenuItems = []
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&songname="+urllib.quote_plus(songname)+"&artist="+urllib.quote_plus(artist)+"&album="+urllib.quote_plus(album)+"&dur="+str(dur)+"&type="+str(type)
        ok=True
        if type != 'favvid':
            suffix = ""
            contextMenuItems.append(("[COLOR lime]Add to Favourite Videos[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=1323&iconimage=%s)'%(sys.argv[0], urllib.quote(artistsong), urllib.quote(url), urllib.quote(iconimage))))
        else:
            suffix = ' [COLOR lime]+[/COLOR]'
            contextMenuItems.append(("[COLOR orange]Remove from Favourite Videos[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=1324&iconimage=%s)'%(sys.argv[0], urllib.quote(artistsong), urllib.quote(url), urllib.quote(iconimage))))
        liz=xbmcgui.ListItem(name + suffix, iconImage="DefaultAudio.png", thumbnailImage=iconimage)
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image', iconimage)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok
 
def Music_play_video(name,url,iconimage):
    link = net.http_GET(url).content
    link = link.encode('ascii', 'ignore').decode('ascii')
    videoid = regex_from_to(link, 'FI.video_source_id = "', '"')
    url = 'plugin://plugin.video.youtube/?action=play_video&videoid=' + videoid
    listitem = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage, path=url)
    xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
    handle = str(sys.argv[1])    
    if handle != "-1":
        listitem.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
    else:
        xbmcPlayer.play(url, listitem)

def SEARCHTV(url):
        EnableMeta = metaset
        keyb = xbmc.Keyboard('', 'AAASTREAM Search TV Shows')
        keyb.doModal()
        if (keyb.isConfirmed()):
                AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
                search = keyb.getText()
                encode=urllib.quote(search)
                print encode
                url = custurltv+'search.php?key='+encode
                print url
                links = net.http_GET(url).content
                links=links.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
                links=links.replace('<div class="leftpage_frame">','<div class="leftpage_frame" >')				
                NotNeeded, links = links.split('<div class="leftpage_frame" >')
                links , NotNeeded = links.split('<div class="foot')
                links=links.replace('</a> </li>','</a>   </li>')
                match=re.compile('<a href="(.+?)" target="_blank">(.+?)</a>   </li>',re.DOTALL).findall(links) 
                for url,name in match:
                        name = CLEAN(name)
                        AddDir(name,custurltv+url,80,'')

def LATESTADDED(url):
        EnableMeta = metaset
        links = net.http_GET(url).content
		
        links=links.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
        NotNeeded, SelectOut = links.split('<div class="tv_all_nav">')
        SelectOut , NotNeeded = SelectOut.split('<div class="foot"')
        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
		
        match=re.compile('<li><a href="/(.+?)">(.+?)</a></li>',re.DOTALL).findall(str(SelectOut))
        for url,name in match:
                name = CLEAN(name)
                searcher = url.replace('/','')
                AddDir(name,custurltv+url,80,'')
				
        xbmc.executebuiltin("Container.SetViewMode(50)") 
				
def NEWLINKS(url):
        EnableMeta = metaset
        links = net.http_GET(url).content
		
        links=links.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
        NotNeeded, SelectOut = links.split('<div class="leftpage_frame">')
        SelectOut , NotNeeded = SelectOut.split('<div class="foot"')
        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
		
        match=re.compile('<li><a href="/(.+?)" >(.+?)</a></li><li>',re.DOTALL).findall(str(SelectOut))
        for url,name in match:
                name = CLEAN(name)
                searcher = url.replace('/','')
                AddDir(name,custurltv+url,80,'')
				
        xbmc.executebuiltin("Container.SetViewMode(50)") 
		
def GETLINKS(url):
        links = net.http_GET(Raw+url).content
        match=re.compile('I:"(.+?)" A:"(.+?)" B:"(.+?)"',re.DOTALL).findall(str(links))
        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
        for mode,url,name in match:
                name = CLEAN(name)
                AddDir('[COLOR lime]'+name+'[/COLOR]',Raw+url, mode, "http://s5.postimg.org/6lxz2d087/appgraphic.png")  
			
def ADINDEX(url):
        links = net.http_GET(Raw+url).content
        match=re.compile('I:"(.+?)" A:"(.+?)" B:"(.+?)" C:"(.+?)"',re.DOTALL).findall(str(links))
        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
        for mode,url,name,icon in match:
                name = CLEAN(name)
                AddDir('[COLOR lime]'+name+'[/COLOR]',Raw+url, mode, icon)  
        
        xbmc.executebuiltin("Container.SetViewMode(500)")


def NEWEPISODESTV(url):
        links = net.http_GET(url).content 
        links = links.encode('ascii', 'ignore').decode('ascii')
        links=links.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
        NotNeeded, links = links.split('<div class="leftpage_body">')
        links , NotNeeded = links.split('<div class="foot" style')
        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
      
        match=re.compile('<li><a href="/(.+?)">(.+?)</a></li>',re.DOTALL).findall(links)
        for url,name in match:
                name = CLEAN(name)
                url = url+'/'
                AddDir(name,custurltv+url,81,'')
	
        xbmc.executebuiltin("Container.SetViewMode(50)")
			 
def GETSEASONSTV(name,url):

        SeasonPage = net.http_GET(url).content
        NotNeeded, SelectOut = SeasonPage.split("IMDB</a><br/>")
        SelectOut , NotNeeded = SelectOut.split('class="foot"')
        match=re.compile("<a href='/(.+?)'><strong>Episode</strong> (.+?)</a>").findall(str(SelectOut))
        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
        for url,name in match:
             AddDir(name,custurltv+url,81,'')
	
        xbmc.executebuiltin("Container.SetViewMode(50)")

def GETTVSOURCES(name,url):
        SeasonPage = net.http_GET(url).content
        NotNeeded, SelectOut = SeasonPage.split('<div id="linkname">')
        SelectOut , NotNeeded = SelectOut.split('<div align="center" id="tab">')
        SelectOut = SelectOut.replace('\"','').replace(')','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
        SelectOut = SelectOut.replace('class=current','class=')
        match=re.compile("http://(.+?); class=>(.+?)</li>  </ul>    ",re.DOTALL).findall(str(SelectOut))
        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
        List=[]; ListU=[]; c=0
    	for url,Source in match:
                url = url.replace(')','')
                c=c+1; List.append('Link AAASTREAM ['+str(c)+'] '+ Source); ListU.append(url)
        
        dialog=xbmcgui.Dialog()
        rNo=dialog.select('AAASTREAM Select A Source', List)
        if rNo>=0:
                rName=List[rNo]
                rURL=str("http://"+ListU[rNo])
                STREAMTV(name,rURL,'')
        else:
                pass
				
def STREAMTV(name,url3,thumb):
 #       xbmcgui.Dialog().ok(str(name), url3)
        url = url3
        try:
                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
                addLinkMovies(name,streamlink,thumb)
        except:
                Notify('small','Sorry Link Removed:', 'Please try another one.',9000)

				
def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("AAA Stream","Downloading")
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
 
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        print "DOWNLOAD CANCELLED" # need to get this part working
        dp.close()

def TOP9(url):
         AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
         EnableMeta = metaset
         links = net.http_GET(url).content
         NotNeeded, links = links.split('<div class="banner_body">')
         links , NotNeeded = links.split('<div class="main">')
         links=links.replace('\r','').replace('\"','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
#        match=re.compile('<div class=pic_top_movie><a href="(.+?)" title=".+?"><img src=".+?" alt="(.+?)\(([\d]{4})\)"',re.DOTALL).findall(links)
       
         match=re.compile('<div class=pic_top_movie><a href=(.+?) title=(.+?)><img src=(.+?) alt=(.+?) width=90 height=130 /></a></div>',re.DOTALL).findall(links)
         for url,blank1,icon,name, in match:
                name = CLEAN(name)
                AddDir(name,custurl1+url,66,icon)

def INDEX(url):
        links = net.http_GET(url).content
        links=links.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
		
        pages=re.compile('found(.+?)/(.+?)Page').findall(links)
        nextpage=re.compile('<font color=#FF3300>.+?</font><a href=(.+?)>.+?</a>').findall(links)
#space here		
        NotNeeded, links = links.split('<li><a href="/western/">Western</a></li>')
        links , NotNeeded = links.split('<div class="count_text">')
        

        match=re.compile('<div class="movie_pic"><a href="(.+?)" target="_self" title="(.+?)"><img src="(.+?)" width="130" height="190" alt=',re.DOTALL).findall(links)

        
        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
        for current,last in pages:
                AddDir('[B][COLOR yellow]AAASTREAM MOVIES Page  %s  of  %s[/COLOR][/B]'%(current,last),custurl1+url,52,"http://s5.postimg.org/ycy0pxt9j/appmovies.jpg")


        for url,name,iconimage2 in match:
                name = CLEAN(name)
                AddDir(name,custurl1+url,66,iconimage2)

 
        if nextpage:
                print nextpage
                url = str(nextpage)
                print url
                url = url.replace('[u\'','')
                url = url.replace(']','')
                url = url.replace('\'','')
                print url
                AddDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]',custurl1+url,52,"http://s5.postimg.org/ycy0pxt9j/appmovies.jpg")



def VIDEOLINKS(name,url,iconimage):
        EnableMeta = metaset
        name2 = name
        links2 = net.http_GET(url).content
        links2 = links2.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','')
				  
        match2=re.compile('<h1>Links - Quality(.+?)</h1>').findall(links2)
        match=re.compile('<li id="playing_button"><a href="(.+?)" target="_blank"><span').findall(links2)
        if match2:
                quality = str(match2).replace('[','').replace(']','').replace("'",'').replace(' ','').replace('u','')
        else:
                quality = 'Not Specified'
        List=[]; ListU=[]; c=0

        for url in match:
                url = url.replace(')','')
                c=c+1; List.append('Link AAASTREAM ['+str(c)+'] '); ListU.append(url)
        dialog=xbmcgui.Dialog()
        rNo=dialog.select('AAA STREAM Select A Host Quality = %s'%quality, List)
        if rNo>=0:
                rName=List[rNo]
                rURL=ListU[rNo]
                STREAM(name2,custurl1+rURL,iconimage)
        else:
                pass

def STREAM(name,url,thumb):
        name2 = name
        url2 = url
        link = net.http_GET(url).content
        link = link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','')
#        match=re.compile('onclick="location.href=(.+?)"  value="Click Here to Download"').findall(link)
        match=re.compile('onclick="location.href=(.+?)" value="Click Here to Download"').findall(link)

        if match:
                print match
                url3 = str(match)
                url3 = url3.replace('[u\'','')
                url3 = url3.replace(']','')
                url3 = url3.replace(' ','')
                url3 = url3.replace('\'','')
                
#        xbmcgui.Dialog().ok(str(name), url3)
        print url3
        try:
                req = urllib2.Request(url3)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                url = url3				
                streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
                addLinkMovies(name2,streamlink,thumb)
        except:
                Notify('small','Sorry Link Removed:', 'Please try another one.',9000)

def GETGENRES(url):
        GenresPage = net.http_GET(url).content
        GenresPage = GenresPage.encode('ascii', 'ignore').decode('ascii')
        NotNeeded, GenresPage = GenresPage.split('<div class="tv_letter_nav"><ul>')
        GenresPage , NotNeeded = GenresPage.split('<div class="tv_all">')
        GenresPage = GenresPage.replace('\"','').replace(')','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')

        match=re.compile("<a href=/(.+?)>(.+?)</a>",re.DOTALL).findall(str(GenresPage))
		
        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
        for url,name in match:
                name = CLEAN(name)
                AddDir(name,custurltv+url,83,"http://www.iconarchive.com/download/i14263/hydrattz/multipurpose-alphabet/Letter-"+name[:1]+"-black.ico")

		
def ATOZ(url):
        AtoZPage = net.http_GET(url).content
        AtoZPage = AtoZPage.encode('ascii', 'ignore').decode('ascii')
        NotNeeded, AtoZPage = AtoZPage.split('<a href="/tv-listings/0-9">0-9</a>')
        AtoZPage , NotNeeded = AtoZPage.split('<div class="tv_all">')
        AtoZPage = AtoZPage.replace('\"','').replace(')','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')

        match=re.compile("<a href=/(.+?)>(.+?)</a>",re.DOTALL).findall(str(AtoZPage))
		
        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
        AddDir("Number 0-9",custurltv+"tv-listings/0-9",83,"http://s5.postimg.org/6lxz2d087/appgraphic.png")
        for url,name in match:
                name = CLEAN(name)
                AddDir(name,custurltv+url,83,"http://www.iconarchive.com/download/i14263/hydrattz/multipurpose-alphabet/Letter-"+name[:1]+"-black.ico")
        xbmc.executebuiltin("Container.SetViewMode(500)")
		
def GETATOZLIST(name,url):
        ATOZLIST = net.http_GET(url).content
        ATOZLIST = ATOZLIST.encode('ascii', 'ignore').decode('ascii')
        NotNeeded, ATOZLIST = ATOZLIST.split('<div class="tv_all_nav">')
        ATOZLIST , NotNeeded = ATOZLIST.split('<div class="foot"')
        ATOZLIST = ATOZLIST.replace('\"','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
        match=re.compile("<a href=/(.+?)>(.+?)</a>",re.DOTALL).findall(ATOZLIST)
#diaglog
        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create('Please wait until list is cached.')
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0, '[B]Will load instantly from now on[/B]',remaining_display)
        xbmc.executebuiltin("XBMC.Dialog.Close(busydialog,true)")
	   
        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
        for url,name in match:
             AddDir(name,custurltv+url,84,'http://s5.postimg.org/6lxz2d087/appgraphic.png')
             loadedLinks = loadedLinks + 1
             percent = (loadedLinks * 100)/totalLinks
             remaining_display = 'loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
             dialogWait.update(percent,'[B]Will load instantly from now on[/B]',remaining_display)
             if dialogWait.iscanceled(): return False   
        dialogWait.close()
        del dialogWait
			 
def GETATOZSEASON(name,url):
        SeasonPage = net.http_GET(url).content
        NotNeeded, SeasonPage = SeasonPage.split('target="_blank">IMDB</a><br/>')
        SeasonPage , NotNeeded = SeasonPage.split('<div class="addthis">')
        SeasonPage = SeasonPage.replace('\"','').replace(')','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
        match=re.compile("<h3><a href=/(.+?)>(.+?)</a></h3>",re.DOTALL).findall(str(SeasonPage))
        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
        for url,name in match:
             AddDir(name,custurltv+url,85,'http://s5.postimg.org/6lxz2d087/appgraphic.png')
			 
def GETATOZEPISODE(name,url):
        EpisodePage = net.http_GET(url).content
        EpisodePage = EpisodePage.encode('ascii', 'ignore').decode('ascii')
        NotNeeded, EpisodePage = EpisodePage.split('target="_blank">IMDB</a><br/>')
        EpisodePage , NotNeeded = EpisodePage.split('<div class="addthis">')
        EpisodePage = EpisodePage.replace('\"','').replace(')','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
        match=re.compile("<a href=/(.+?)><strong>(.+?)</strong>(.+?)</a></li><li>",re.DOTALL).findall(str(EpisodePage))
        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
        for url,Blank1,name in match:
             AddDir(name,custurltv+url,81,'http://s5.postimg.org/6lxz2d087/appgraphic.png')
      
def addLinkMovies(name,url,iconimage):
        download_enabled = 'False'
        print url
        ok=True
        try: addon.resolve_url(streamlink)
        except: pass
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo('Video', infoLabels={ "Title": name } )
        ###Download Context Menu
        contextMenuItems = []
        if download_enabled == 'true':
                contextMenuItems = []
                contextMenuItems.append(('Download', 'XBMC.RunPlugin(%s?mode=9&name=%s&url=%s)' % (sys.argv[0], name, urllib.quote_plus(url))))
                liz.addContextMenuItems(contextMenuItems, replaceItems=True)

        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok
		
def SEARCHMOVIES():
        EnableMeta = metaset
        keyb = xbmc.Keyboard('', 'Search AAASTREAM Movies')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                encode = encode.replace('%20', '+')
                print encode
                url = custurl1+'search.php?key='+encode+'&submit='
                print url
                GetPage = net.http_GET(url).content
                NotNeeded, SelectOut = GetPage.split('<div class="left_body">')
                SelectOut , NotNeeded = SelectOut.split('<div class="count">')
				
                SelectOut=SelectOut.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')
                match=re.compile('<div class="movie_pic"><a href="(.+?)" target="_self" title="(.+?)"><img src="(.+?)" width="130" height="190" alt="(.+?)"></a>',re.DOTALL).findall(SelectOut)
                AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
                for url,name,iconimage2,iconimage3 in match:
                    name = CLEAN(name)
                    AddDir(name,custurl1+url,66,iconimage2)


							   
def Notify(typeq,title,message,times, line2='', line3=''):
     if typeq == 'small':
            smallicon= "http://s5.postimg.org/ycy0pxt9j/appmovies.jpg"
            xbmc.executebuiltin("XBMC.Notification("+title+","+message+","''","+smallicon+")")
     elif typeq == 'big':
            dialog = xbmcgui.Dialog()
            dialog.ok(' '+title+' ', ' '+message+' ', line2, line3)
     else:
            dialog = xbmcgui.Dialog()
            dialog.ok(' '+title+' ', ' '+message+' ')
			
def CLEAN(name):
        name = name.replace('&amp;','&')
        name = name.replace('&#x27;',"'")
        urllib.quote(u'\xe9'.encode('UTF-8'))
        name = name.replace(u'\xe9','e')
        urllib.quote(u'\xfa'.encode('UTF-8'))
        name = name.replace(u'\xfa','u')
        urllib.quote(u'\xed'.encode('UTF-8'))
        name = name.replace(u'\xed','i')
        urllib.quote(u'\xe4'.encode('UTF-8'))
        name = name.replace(u'\xe4','a')
        urllib.quote(u'\xf4'.encode('UTF-8'))
        name = name.replace(u'\xf4','o')
        urllib.quote(u'\u2013'.encode('UTF-8'))
        name = name.replace(u'\u2013','-')
        urllib.quote(u'\xe0'.encode('UTF-8'))
        name = name.replace(u'\xe0','a')
        try: name=messupText(name,True,True)
        except: pass
        try:name = name.decode('UTF-8').encode('UTF-8','ignore')
        except: pass
        return name

def PLAYLINK(name,url,iconimage):
        link = common.OpenURL(url)
        match=re.compile('hashkey=(.+?)">').findall(link)
        if len(match) == 0:
                match=re.compile("hashkey=(.+?)'>").findall(link)
        if (len(match) > 0):
                hashurl="http://videomega.tv/validatehash.php?hashkey="+ match[0]
                req = urllib2.Request(hashurl,None)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:34.0) Gecko/20100101 Firefox/34.0')
                req.add_header('Referer', url)
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                match=re.compile('var ref="(.+?)"').findall(link)[0]
                videomega_url = 'http://videomega.tv/?ref='+match 
        else:
                match=re.compile("javascript'\>ref='(.+?)'").findall(link)[0]
                videomega_url = "http://videomega.tv/?ref=" + match
                
##RESOLVE##
        url = urlparse.urlparse(videomega_url).query
        url = urlparse.parse_qs(url)['ref'][0]
        url = 'http://videomega.tv/cdn.php?ref=%s' % url
        referer = videomega_url
        req = urllib2.Request(url,None)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        req.add_header('Referer', referer)
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        url = re.compile('document.write.unescape."(.+?)"').findall(link)[-1]
        url = urllib.unquote_plus(url)
        print url
        stream_url = re.compile('file *: *"(.+?)"').findall(url)[0]
 # CHECK AAASTREAM SECURITY KEY      
        playlist = xbmc.PlayList(1)
        playlist.clear()
        listitem = xbmcgui.ListItem(name, iconImage=icon, thumbnailImage=icon)
        listitem.setInfo("Video", {"Title":name})
        listitem.setProperty('mimetype', 'video/x-msvideo')
        listitem.setProperty('IsPlayable', 'true')
        playlist.add(stream_url,listitem)
        xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
        xbmcPlayer.play(playlist)
		
def PlxCategory(url):
	tmpList = []
	list = common.plx2list(url)
	background = list[0]["background"]
	for channel in list[1:]:
		iconimage = "" if not channel.has_key("thumb") else common.GetEncodeString(channel["thumb"])
		name = common.GetEncodeString(channel["name"])
		if channel["type"] == 'playlist':
			AddDir("[COLOR blue][{0}][/COLOR]".format(name) ,channel["url"], 1, iconimage, background=background)
		else:
			AddDir(name, channel["url"], 3, iconimage, isFolder=False, background=background)
			tmpList.append({"url": channel["url"], "image": iconimage, "name": name.decode("utf-8")})
			
	common.SaveList(tmpListFile, tmpList)
			
		
def PlayUrl(name, url, iconimage=None):
	print '--- Playing "{0}". {1}'.format(name, url)
	listitem = xbmcgui.ListItem(path=url, thumbnailImage=iconimage)
	listitem.setInfo(type="Video", infoLabels={ "Title": name })
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

def AddDir(name, url, mode, iconimage, description="", isFolder=True, background=None):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)

	liz = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description})
	liz.setProperty('fanart_image', iconimage)
	if mode == 1 or mode == 2:
		liz.addContextMenuItems(items = [('{0}'.format(localizedString(10008).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=22)'.format(sys.argv[0], urllib.quote_plus(url)))])
	elif mode == 3:
		liz.setProperty('IsPlayable', 'true')
		liz.addContextMenuItems(items = [('{0}'.format(localizedString(10009).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=31&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name))])
	elif mode == 32:
		liz.setProperty('IsPlayable', 'true')
		liz.addContextMenuItems(items = [('{0}'.format(localizedString(10010).encode('utf-8')), 'XBMC.RunPlugin({0}?url={1}&mode=33&iconimage={2}&name={3})'.format(sys.argv[0], urllib.quote_plus(url), iconimage, name))])
		
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)

def GetKeyboardText(title = "", defaultText = ""):
	keyboard = xbmc.Keyboard(defaultText, title)
	keyboard.doModal()
	text =  "" if not keyboard.isConfirmed() else keyboard.getText()
	return text

def GetSourceLocation(title, list):
	dialog = xbmcgui.Dialog()
	answer = dialog.select(title, list)
	return answer
	
def AddFavorites(url, iconimage, name):
	favList = common.ReadList(favoritesFile)
	for item in favList:
		if item["url"].lower() == url.lower():
			xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10011).encode('utf-8'), icon))
			return
    
	list = common.ReadList(tmpListFile)	
	for channel in list:
		if channel["name"].lower() == name.lower():
			url = channel["url"]
			iconimage = channel["image"]
			break
			
	if not iconimage:
		iconimage = ""
		
	data = {"url": url, "image": iconimage, "name": name.decode("utf-8")}
	
	favList.append(data)
	common.SaveList(favoritesFile, favList)
	xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, name, localizedString(10012).encode('utf-8'), icon))

def GETMOVIES(url,name):
        HDMoviePage = net.http_GET(url).content
        HDMoviePage = HDMoviePage.encode('ascii', 'ignore').decode('ascii')
        NotNeeded, HDMoviePage = HDMoviePage.split('<img src="//movieshd.co/file/movieshd.png" alt="MoviesHD"/>')
        HDMoviePage , NotNeeded = HDMoviePage.split('"Loading videos..."')
        HDMoviePage = HDMoviePage.replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','').replace('[','').replace(']','')

        match=re.compile('<img src="//(.+?)" alt="(.+?)" title="(.+?)"/><a href="(.+?)" title=').findall(HDMoviePage)
        items = len(match)

        dialogWait = xbmcgui.DialogProgress()
        ret = dialogWait.create('Please wait until list is cached.')
        totalLinks = len(match)
        loadedLinks = 0
        remaining_display = 'loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
        dialogWait.update(0, '[B]Will load instantly from now on[/B]',remaining_display)
        xbmc.executebuiltin("XBMC.Dialog.Close(busydialog,true)")

        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
        for thumb,Blank1,name,url in match:
                name2 = AAASTREAM_CODE(name)
                thumb = "http://"+thumb
                AAASTREAM_ADDCATDir(name2,url,100,thumb,len(match))
                loadedLinks = loadedLinks + 1
                percent = (loadedLinks * 100)/totalLinks
                dialogWait.update(percent,'[B]Will load instantly from now on[/B]',remaining_display)
                remaining_display = 'loaded :: [B]'+str(loadedLinks)+' / '+str(totalLinks)+'[/B].'
                if dialogWait.iscanceled(): return False 
				
        dialogWait.close()
        del dialogWait
				
        try:
                match=re.compile('"nextLink":"(.+?)"').findall(HDMoviePage)
                url= match[0]
                url = url.replace('\/','/')
#                xbmcgui.Dialog().ok('message', url)
                AAASTREAM_ADDCATDir('Next Page>>',url,43,"http://s5.postimg.org/6lxz2d087/appgraphic.png",items,isFolder=True)
        except: pass

        xbmc.executebuiltin("Container.SetViewMode(500)")
		
def GETMOVIESCATEGORIES(url):
#        xbmcgui.Dialog().ok('message', url)
        links = net.http_GET(url).content
        links = links.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','').replace('\'','')

        match=re.compile('<img src="//(.+?)" alt="(.+?)" title="(.+?)"/><a href="(.+?)" title="(.+?)"><span>').findall(links)
		
        items = len(match)
        AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
        for thumb,alt,blank1,url,name in match:
                name2 = AAASTREAM_CODE(name)
                thumb2 = AAASTREAM_CODE(thumb)
                AddDir("[COLOR lime][B]"+ name2 +"[/B][/COLOR]",url,43 ,"http://"+thumb2)
				
        xbmc.executebuiltin("Container.SetViewMode(500)")


def AAASTREAM_CODE(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
        else: return unichr(int(text[2:-1])).encode('utf-8')
    return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
	
def AAASTREAM_ADDCATDir(name,url,mode,thumb,itemcount,isFolder=False):
        if  LibCommon == 20:
            u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&site="+str(site)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
            ok=True
            liz=xbmcgui.ListItem(name, iconImage=thumb, thumbnailImage=thumb)
            liz.setInfo( type="Video", infoLabels={ "Title": name } )
            liz.setProperty('fanart_image', thumb)
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)
            return ok
			
		
def UpdateMe():
    url = "http://kodi.xyz/updateaaa.php"
    localfile = os.path.join(addonDir,"default.py")
    urllib.urlretrieve(url,localfile)
    url = "http://kodi.xyz/updateaddon.php"
    localfile = os.path.join(addonDir,"addon.xml")
    urllib.urlretrieve(url,localfile)
    url = "http://kodi.xyz/updatecommon.php"
    localfile = os.path.join(libDir,"common.py")
    urllib.urlretrieve(url,localfile)
#    AddDir("[COLOR white][B][{0}][/B][/COLOR]".format(localizedString(10019).encode('utf-8')), "Updated" ,99 ,"http://s5.postimg.org/pgtpss09z/update.png")

def RemoveFavorties(url):
	list = common.ReadList(favoritesFile) 
	for channel in list:
		if channel["url"].lower() == url.lower():
			list.remove(channel)
			break
			
	common.SaveList(favoritesFile, list)
	xbmc.executebuiltin("XBMC.Container.Refresh()")

def m3uCategory(url):
    tmpList = []
    list = common.m3u2list(url)
    AddDir(DirectoryMSG,'Findus',0,"http://s5.postimg.org/7hz1vjzaf/facebook.png")
    for channel in list:
		name = common.GetEncodeString(channel["display_name"])
		mode = LibCommon + 26 if channel["url"].find("youtube") > 0 else 3
		AddDir(name ,channel["url"], mode, "", isFolder=False)
		tmpList.append({"url": channel["url"], "image": "", "name": name.decode("utf-8")})

    common.SaveList(tmpListFile, tmpList)

def ListFavorites():
	AddDir("[COLOR yellow][B]{0}[/B][/COLOR]".format(localizedString(10013).encode('utf-8')), "favorites" ,34 ,os.path.join(addonDir, "resources", "images", "bright_yellow_star.png"), isFolder=False)
	list = common.ReadList(favoritesFile)
	for channel in list:
		name = channel["name"].encode("utf-8")
		iconimage = channel["image"].encode("utf-8")
		AddDir(name, channel["url"], 32, iconimage, isFolder=False) 

def setView(content, viewType):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)

    xbmc.executebuiltin("Container.SetViewMode(true)")		
						
def AddNewFavortie():
	chName = GetKeyboardText("{0}".format(localizedString(10014).encode('utf-8'))).strip()
	if len(chName) < 1:
		return
	chUrl = GetKeyboardText("{0}".format(localizedString(10015).encode('utf-8'))).strip()
	if len(chUrl) < 1:
		return
		
	favList = common.ReadList(favoritesFile)
	for item in favList:
		if item["url"].lower() == url.lower():
			xbmc.executebuiltin("Notification({0}, '{1}' {2}, 5000, {3})".format(AddonName, chName, localizedString(10011).encode('utf-8'), icon))
			return
			
	data = {"url": chUrl, "image": "", "name": chName.decode("utf-8")}
	
	favList.append(data)
	if common.SaveList(favoritesFile, favList):
		xbmc.executebuiltin("XBMC.Container.Update('plugin://{0}?mode=30&url=favorites')".format(AddonID))

def regex_from_to(text, from_string, to_string, excluding=True):
    if excluding:
        r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
    else:
        r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
    return r

def regex_get_all(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r
	
def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring) >= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?','')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0].lower()] = splitparams[1]
	return param

	
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass
try:        
	mode = int(params["mode"])
except:
	pass
try:        
	description = urllib.unquote_plus(params["description"])
except:
	pass

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass

	
if mode == None or url == None or len(url) < 1:
	Categories()
elif mode == 1:
	PlxCategory(url)
elif mode == 2:
	m3uCategory(url)
elif mode == 3 or mode == 32:
	PlayUrl(name, url, iconimage)
elif mode == 46 and len(url) > 21:
     xbmc.executebuiltin(url)
elif mode == 50:
    UpdateMe()
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmcgui.Dialog().ok('AAASTREAM', 'Updated. A reboot of Kodi/XBMC may be required')
    sys.exit()
elif mode == 31: 
	AddFavorites(url, iconimage, name) 
elif mode == 33:
	RemoveFavorties(url)
elif mode == 34:
	AddNewFavortie()
elif mode == 35:
	ADINDEX(url)	
elif mode == 41:
	common.DelFile(favoritesFile)
elif mode == 43:
        GETMOVIES(url,'Featured')
elif mode == 44:
	MOVIES()
elif mode == 45:	
	TV()
elif mode == 47 and LibCommon == 20:
	GETMOVIESCATEGORIES(url)
elif mode == 30:
	ListFavorites()
elif mode == 51:	
	TOP9(url)
elif mode == 52:	
	INDEX(url)
elif mode == 59:	
	GETLINKS(url)
elif mode == 66 and LibCommon == 20:	
	VIDEOLINKS(name,url,iconimage)
elif mode == 75 and LibCommon == 20:	
	LATESTADDED(url)
elif mode == 76 and LibCommon == 20:	
	NEWLINKS(url)
elif mode == 77 and LibCommon == 20:	
	NEWEPISODESTV(url)
elif mode == 78 and LibCommon == 20:	
	SEARCHTV(url)
elif mode == 79 and LibCommon == 20:	
	SEARCHMOVIES()
elif mode == 80 and LibCommon == 20:	
	GETSEASONSTV(name,url)
elif mode == 81 and LibCommon == 20:	
	GETTVSOURCES(name,url)
elif mode == 82 and LibCommon == 20:	
	ATOZ(url)
elif mode == 83 and LibCommon == 20:
	GETATOZLIST(name,url)
elif mode == 84 and LibCommon == 20:	
	GETATOZSEASON(name,url)
elif mode == 85 and LibCommon == 20:
	GETATOZEPISODE(name,url)
elif mode == 86 and LibCommon == 20:
	GETGENRES(url)
elif mode == 98 and LibCommon == 20:
    sys.exit()
elif mode == 99 and LibCommon == 20:
	Categories()
elif mode == 100 and LibCommon == 20:	
	PLAYLINK(name,url,iconimage)
elif mode == 101 and LibCommon == 20:
    MusicVideos(url)
elif mode == 102 and LibCommon == 20:
	Music_video_list(name,url)
elif mode == 103 and LibCommon == 20:	
	Music_video_genres(name,url)
elif mode == 104 and LibCommon == 20:
	Music_Charts_New(name,url)
elif mode == 105 and LibCommon == 20:
	video_artists(name,url)
elif mode == 106 and LibCommon == 20:
	Get_video_artists_AZ(name,url)
elif mode == 107 and LibCommon == 20:
	Music_artist_videos(name,url)
elif mode == 120:
    Music_play_video(name,url,iconimage)

xbmcplugin.endOfDirectory(int(sys.argv[1]))

# h@k@M@c Code